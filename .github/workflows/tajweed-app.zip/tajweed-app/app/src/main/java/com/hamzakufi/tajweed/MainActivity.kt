package com.hamzakufi.tajweed

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.pdf.PdfRenderer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.text.InputType
import android.util.LruCache
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import com.github.chrisbanes.photoview.PhotoView
import java.io.File
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var pager: ViewPager2
    private lateinit var seek: SeekBar
    private lateinit var label: TextView
    private lateinit var pfd: ParcelFileDescriptor
    private lateinit var renderer: PdfRenderer

    private val prefs by lazy { getSharedPreferences("reader", MODE_PRIVATE) }
    private val lock = Any()
    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private val cache = LruCache<Int, Bitmap>(6)
    private var night = false
    private var total = 0

    private val invert = ColorMatrixColorFilter(
        ColorMatrix(
            floatArrayOf(
                -1f, 0f, 0f, 0f, 255f,
                0f, -1f, 0f, 0f, 255f,
                0f, 0f, -1f, 0f, 255f,
                0f, 0f, 0f, 1f, 0f
            )
        )
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setSupportActionBar(findViewById<Toolbar>(R.id.toolbar))

        val f = File(cacheDir, "book.pdf")
        if (!f.exists() || f.length() == 0L) {
            assets.open("book.pdf").use { i -> f.outputStream().use { o -> i.copyTo(o) } }
        }
        pfd = ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY)
        renderer = PdfRenderer(pfd)
        total = renderer.pageCount
        night = prefs.getBoolean("night", false)

        pager = findViewById(R.id.pager)
        seek = findViewById(R.id.seek)
        label = findViewById(R.id.pageLabel)

        pager.layoutDirection = View.LAYOUT_DIRECTION_RTL
        pager.offscreenPageLimit = 1
        pager.adapter = PageAdapter()
        seek.max = total - 1

        val start = prefs.getInt("page", 0).coerceIn(0, total - 1)
        pager.setCurrentItem(start, false)
        onPageChanged(start)

        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) = onPageChanged(position)
        })

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) pager.setCurrentItem(p, false)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        applyNight()
    }

    private fun onPageChanged(p: Int) {
        prefs.edit().putInt("page", p).apply()
        label.text = "${p + 1} / $total"
        seek.progress = p
        invalidateOptionsMenu()
    }

    private fun applyNight() {
        pager.setBackgroundColor(if (night) Color.parseColor("#121212") else Color.parseColor("#ECEFF1"))
        pager.adapter?.notifyDataSetChanged()
    }

    private fun bookmarks(): MutableSet<String> =
        HashSet(prefs.getStringSet("bm", emptySet()) ?: emptySet())

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        val marked = bookmarks().contains(pager.currentItem.toString())
        menu.findItem(R.id.action_bookmark).setIcon(
            if (marked) android.R.drawable.btn_star_big_on else android.R.drawable.btn_star_big_off
        )
        menu.findItem(R.id.action_night).isChecked = night
        return super.onPrepareOptionsMenu(menu)
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.action_bookmark -> {
                val set = bookmarks()
                val key = pager.currentItem.toString()
                if (!set.remove(key)) set.add(key)
                prefs.edit().putStringSet("bm", set).apply()
                invalidateOptionsMenu()
            }
            R.id.action_bookmarks -> showBookmarks()
            R.id.action_goto -> showGoTo()
            R.id.action_night -> {
                night = !night
                prefs.edit().putBoolean("night", night).apply()
                applyNight()
                invalidateOptionsMenu()
            }
            else -> return super.onOptionsItemSelected(item)
        }
        return true
    }

    private fun showBookmarks() {
        val pages = bookmarks().mapNotNull { it.toIntOrNull() }.sorted()
        if (pages.isEmpty()) {
            Toast.makeText(this, R.string.no_bookmarks, Toast.LENGTH_SHORT).show()
            return
        }
        val items = pages.map { getString(R.string.page_n, it + 1) }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(R.string.bookmarks)
            .setItems(items) { _, i -> pager.setCurrentItem(pages[i], false) }
            .show()
    }

    private fun showGoTo() {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            hint = "1 - $total"
            setPadding(48, 32, 48, 32)
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.goto_page)
            .setView(input)
            .setPositiveButton(R.string.go) { _, _ ->
                val n = input.text.toString().toIntOrNull()
                if (n != null && n in 1..total) pager.setCurrentItem(n - 1, false)
                else Toast.makeText(this, R.string.invalid_page, Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun renderPage(i: Int): Bitmap = synchronized(lock) {
        renderer.openPage(i).use { page ->
            val w = 1400
            val h = (w.toFloat() * page.height / page.width).toInt()
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            bmp.eraseColor(Color.WHITE)
            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            bmp
        }
    }

    inner class PageAdapter : RecyclerView.Adapter<PageAdapter.VH>() {
        inner class VH(val photo: PhotoView) : RecyclerView.ViewHolder(photo)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = PhotoView(parent.context).apply {
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
                )
                scaleType = ImageView.ScaleType.FIT_CENTER
                maximumScale = 5f
            }
            return VH(v)
        }

        override fun getItemCount() = total

        override fun onBindViewHolder(h: VH, position: Int) {
            h.photo.tag = position
            h.photo.colorFilter = if (night) invert else null
            val cached = cache.get(position)
            h.photo.setImageBitmap(cached)
            if (cached == null) {
                executor.execute {
                    val b = renderPage(position)
                    cache.put(position, b)
                    main.post { if (h.photo.tag == position) h.photo.setImageBitmap(b) }
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdownNow()
        try { renderer.close(); pfd.close() } catch (_: Exception) {}
    }
}
